#include <ros/ros.h>
int main(int argc, char const *argv[])
{
    ros
    return 0;
}
