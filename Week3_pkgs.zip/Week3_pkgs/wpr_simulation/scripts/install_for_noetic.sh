#!/bin/bash
sudo apt install -y ros-noetic-desktop-full
sudo apt install -y ros-noetic-navigation
sudo apt install -y ros-noetic-joy
sudo apt install -y ros-noetic-gazebo-ros-control
sudo apt install -y ros-noetic-joint-state-controller
sudo apt install -y ros-noetic-position-controllers
sudo apt install -y ros-noetic-effort-controllers
sudo apt install -y ros-noetic-cv-bridge
sudo apt install -y ros-noetic-controller-manager
sudo apt install -y ros-noetic-hector-mapping
sudo apt install -y ros-noetic-gmapping