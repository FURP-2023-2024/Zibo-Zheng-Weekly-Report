#!/bin/bash
sudo apt-get install -y ros-melodic-desktop-full
sudo apt-get install -y ros-melodic-navigation
sudo apt-get install -y ros-melodic-joy
sudo apt-get install -y ros-melodic-gazebo-ros-control
sudo apt-get install -y ros-melodic-joint-state-controller
sudo apt-get install -y ros-melodic-position-controllers
sudo apt-get install -y ros-melodic-effort-controllers
sudo apt-get install -y ros-melodic-cv-bridge
sudo apt-get install -y ros-melodic-controller-manager
sudo apt-get install -y ros-melodic-hector-mapping
sudo apt-get install -y ros-melodic-gmapping