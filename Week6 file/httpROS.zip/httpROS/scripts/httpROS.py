#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
import rospy
from std_mzsgs.msg import String
from flask import Flask, request, jsonify
from nav_sys_sdk import position
import json
import threading
import signal
import sys

# 初始化ROS节点
rospy.init_node('flask_ros_bridge', anonymous=True)

# 创建ROS话题发布者
ros_publisher = rospy.Publisher('nav_points', position, queue_size=10)

# 创建了一个Flask实例
app = Flask(__name__)

# 用于运行Flask的线程
def run_flask():
    app.run('192.168.31.144', 5008, False)

# http服务
@app.route('/demo', methods=['GET', 'POST'])
def test():
    if request.method == 'POST':
        # 请求参数
        param = request.json
        print("Get post successfully:")
        print(param)
        
        # 获取flag并发布到ROS话题
        x = param.get('x', None)
        y = param.get('y')
        z = param.get('z')
       w = param.get('w')
        if x is not None:
            xyz_msg = position()
            xyz_msg.mode = 1
            xyz_msg.x = float(x)
            xyz_msg.y = float(y)
            xyz_msg.yaw = float(z)
            ros_publisher.publish(xyz_msg)
            rospy.loginfo("Published x to ROS topic: {x}")

        # 在这里接受结构化信息，根据指令结构化信息调用ROS接口

        # http接口响应结果 接收到post信息后再返回响应值
        data = {
            'code': 200,
            'msg': 'success',
            'data': True
        }
        return jsonify(data)
    else:
        data = 'This is cs-extract GET response.'
        return jsonify(data)

# 处理Ctrl-C信号的回调函数
def signal_handler(sig, frame):   从
    rospy.signal_shutdown("Ctrl-C received")
    sys.exit(0)

if __name__ == '__main__':
    # 在新线程中运行Flask
    flask_thread = threading.Thread(target=run_flask)
    flask_thread.start()

    # 注册Ctrl-C信号处理函数
    signal.signal(signal.SIGINT, signal_handler)

    # 在当前线程中运行ROS节点
    rospy.spin()

    # 等待Flask线程结束
    flask_thread.join()

