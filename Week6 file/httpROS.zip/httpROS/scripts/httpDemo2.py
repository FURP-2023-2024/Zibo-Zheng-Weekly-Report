from flask import Flask, request, jsonify
import json
import requests


# 创建了一个Flask实例
app = Flask(__name__)

#http服务
@app.route('/demo', methods=['GET', 'POST'])
def test():
    
    if request.method == 'POST':
	    #请求参数
        param = request.json
        print("Get post successfully:")
        print(param)
        flag = param.get('flag')
        print("The flag is: "+flag)
        #http接口响应结果 接收到post信息后再返回响应值
        data = {
            'code': 200,
            'msg': 'success',
            'data': True
        }
        return jsonify(data)
    else:
        data = 'This is cs-extract GET response.'
        return jsonify(data)
    

if __name__ == '__main__':
    app.run('192.168.31.254', 5004, False)
