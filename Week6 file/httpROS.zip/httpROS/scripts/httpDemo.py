from flask import Flask, request, jsonify
import json
import requests


TRACK_ID = '12345'
TRACE_ID = 'spark-gpt-demo'
HEADERS = {'Content-Type': 'application/json;charset=utf8'}
CHAT_URL = 'http://10.3.152.51:30002/turing/v3/func/gpt'
PROMPT = [
    #{"role": "system", "content": "You are a helpful assistant."},
    {"role": "user", "content": "下面我会提供给你一个三元组，你要根据这个三元组提供一些额外的信息来丰富它，并将它们组成一段话，但回答不要超过50个字"},
    {"role": "assistant", "content": "好的,请提供三元组。"},
]

# 创建了一个Flask实例
app = Flask(__name__)

#调用http示例 用于调用聊天API 可以借鉴这个 替换为ROS API？
def chat_query(content, prompt=PROMPT, trace_id=TRACE_ID, temperature=0.5, max_tokens=1024):
    message = []
    message.extend(prompt)
    message.append({"role": "user", "content": content})
    request_data = {
        'header': {
            'traceId': trace_id
        },
        'parameter': {
            'chat': {
                'temperature': temperature,
                'max_tokens': max_tokens
            }
        },
        'payload': {
            'message': {
                'text': message
            }
        }
    }
    print(request_data)
    chat_result = requests.post(CHAT_URL, headers=HEADERS, json=request_data).json()
    ###
    #print(chat_result)
    ###
    return chat_result

#http服务
@app.route('/demo', methods=['GET', 'POST'])
def test():
    if request.method == 'POST':
	    #请求参数
        param = request.json
        print("Get post successfully:")
        print(param)
        flag = param.get('flag')
        print("The flag is: "+flag)
        #根据指令结构化信息，调用ROS接口
        
        #http接口响应结果 接收到post信息后再返回响应值
        data = {
            'code': 200,
            'msg': 'success',
            'data': True
        }
        return jsonify(data)
    else:
        data = 'This is cs-extract GET response.'
        return jsonify(data)
    

if __name__ == '__main__':
    app.run('172.16.3.8', 5004, False)
