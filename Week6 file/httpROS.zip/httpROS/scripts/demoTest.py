import requests
import json

url = 'http://192.168.238.13:5004/demo'
headers = {'Content-Type': 'application/json;charset=utf-8'}
data = {'flag': '1','points': [{'lon':23.23525,'lat':127.23525}],'height': '20','radius': '5'}

# get  从url上获取状态返回值
# print(requests.get(url).json())
# post 向url上发送http查询端所需属性值
print(requests.post(url, headers=headers, json=data).json())
