import requests
import json

url = 'http://192.168.31.122:5004/demo'
headers = {'Content-Type': 'application/json;charset=utf-8'}
# data = {'flag': '2','points': [{'lon':13.23525,'lat':103.23525}],'height': '40','radius': '15'}
data={'x':'-3','y':'3','z':'0','w':'1'}

# get  从url上获取状态返回值
# print(requests.get(url).json())
# post 向url上发送http查询端所需属性值
print(requests.post(url, headers=headers, json=data).json())
