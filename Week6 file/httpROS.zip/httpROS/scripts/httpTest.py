#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
from flask import Flask, request, jsonify

# 创建了一个Flask实例
app = Flask(__name__)

# 用于运行Flask的线程
def run_flask():
    app.run('10.106.12.194', 5004, False)

# http服务
@app.route('/demo', methods=['GET', 'POST'])
def test():
    if request.method == 'POST':
        # 请求参数
        param = request.json
        print("Get post successfully:")
        print(param)
        
        # 获取flag并发布到ROS话题
        kv_input = param.get('kv_input', None)
        if kv_input is not None:
            voice_txt = kv_input
            print(f"query voice received: {voice_txt}")

        # 在这里接受结构化信息，根据指令结构化信息调用ROS接口

        # http接口响应结果 接收到post信息后再返回响应值
        data = {
            'code': 200,
            'msg': 'success',
            'data': True
        }
        return jsonify(data)
    else:
        data = 'This is cs-extract GET response.'
        return jsonify(data)

if __name__ == '__main__':
    # 在新线程中运行Flask
    run_flask()

